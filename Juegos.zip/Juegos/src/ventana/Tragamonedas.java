/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventana;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;


public class Tragamonedas extends javax.swing.JDialog {

       int a=0;
       int b=0;
       int c=0;
       int d=0;
    public Tragamonedas(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

     public class proceso1 extends Thread{
       
 
    
    @Override
    public void run(){
          while (sec.isSelected()==false) {

        Random random = new Random();
        int numero = random.nextInt(4) + 1;
        
        switch(numero){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("limon.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 jLabel1.setIcon(scaledIcon1);
                 
                 a=1;
             
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("siete.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel1.setIcon(scaledIcon2);
                 a=2;
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("sand.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel1.setIcon(scaledIcon3);
                 a=3;
            
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("ch.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel1.setIcon(scaledIcon4);
                 a=4;
            
            break;
        
       }
         try {
                Thread.sleep(50); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
     }
     }
     
    public class proceso2 extends Thread{
       
 
    
    @Override
    public void run(){
          while (sec.isSelected()==false) {

        Random random = new Random();
        int numero = random.nextInt(4) + 1;
        
        switch(numero){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("limon.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(jLabel2.getWidth(), jLabel2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 jLabel2.setIcon(scaledIcon1);
                  b=1;
             
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("siete.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(jLabel2.getWidth(), jLabel2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel2.setIcon(scaledIcon2);
                 b=2;
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("sand.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel2.setIcon(scaledIcon3);
                 b=3;
            
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("ch.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel2.setIcon(scaledIcon4);
                 b=4;
            
            break;
        
       }
         try {
                Thread.sleep(50); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
     }
     }
       
    public class proceso3 extends Thread{
       
 
    
    @Override
    public void run(){
        while (sec.isSelected()==false) {

        Random random = new Random();
        int numero = random.nextInt(4) + 1;
        
        switch(numero){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("limon.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 jLabel3.setIcon(scaledIcon1);
                  c=1;
             
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("siete.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel3.setIcon(scaledIcon2);
                 c=2;
                
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("sand.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel3.setIcon(scaledIcon3);
                c=3;
            
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("ch.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel3.setIcon(scaledIcon4);
                c=4;
            
            break;
        
       }
        try {
                Thread.sleep(50); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
     }
     }
       public class proceso4 extends Thread{
       
 
    
    @Override
    public void run(){
           while (sec.isSelected()==false) {

        Random random = new Random();
        int numero = random.nextInt(4) + 1;
        
        switch(numero){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("limon.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(jLabel4.getWidth(), jLabel4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 jLabel4.setIcon(scaledIcon1);
                 d=1;
             
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("siete.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(jLabel4.getWidth(), jLabel4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel4.setIcon(scaledIcon2);
                d=2;
                
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("sand.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(jLabel4.getWidth(), jLabel4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel4.setIcon(scaledIcon3);
                d=3;
            
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("ch.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(jLabel4.getWidth(), jLabel4.getHeight(), java.awt.Image.SCALE_SMOOTH));
                jLabel4.setIcon(scaledIcon4);
                d=4;
            
            break;
        
       }
          try {
                Thread.sleep(50); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
     }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel10 = new java.awt.Panel();
        jCheckBox1 = new javax.swing.JCheckBox();
        buttonGroup1 = new javax.swing.ButtonGroup();
        panel1 = new java.awt.Panel();
        panel2 = new java.awt.Panel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        panel3 = new java.awt.Panel();
        sec = new javax.swing.JRadioButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        panel10.setBackground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout panel10Layout = new javax.swing.GroupLayout(panel10);
        panel10.setLayout(panel10Layout);
        panel10Layout.setHorizontalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        panel10Layout.setVerticalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 189, Short.MAX_VALUE)
        );

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        panel1.setBackground(new java.awt.Color(204, 0, 0));

        panel2.setBackground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );

        jLabel2.setText("\n");

        jLabel3.setText("\n");

        panel3.setBackground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
            .addComponent(panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        buttonGroup1.add(sec);
        sec.setText("DETENER");
        sec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("INICIAR");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(sec)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jRadioButton1)
                .addGap(85, 85, 85))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sec)
                    .addComponent(jRadioButton1))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        proceso1 hilo1 = new proceso1();
        proceso2 hilo2 = new proceso2();
        proceso3 hilo3 = new proceso3();
        proceso4 hilo4 = new proceso4();

        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void secActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secActionPerformed
       if(a==b&&a==c&&a==d&&b==a&&b==c&&b==d&&c==a&&c==b&&c==d&&d==a&&d==b&&d==c){
           JOptionPane.showMessageDialog(null,"¡FELICITACIONES!");
       }else{
           JOptionPane.showMessageDialog(null,"¡SIGUE INTENTANDO!");
       }
    }//GEN-LAST:event_secActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tragamonedas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Tragamonedas dialog = new Tragamonedas(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JRadioButton jRadioButton1;
    private java.awt.Panel panel1;
    private java.awt.Panel panel10;
    private java.awt.Panel panel11;
    private java.awt.Panel panel12;
    private java.awt.Panel panel13;
    private java.awt.Panel panel2;
    private java.awt.Panel panel3;
    private javax.swing.JRadioButton sec;
    // End of variables declaration//GEN-END:variables
}
