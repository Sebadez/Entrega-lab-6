/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventana;

import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author misra
 */
public class Dados extends javax.swing.JDialog {

 ImageIcon imagen;
     int suma;
     int num1;
     int num2;
    public Dados(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

   public class proceso1 extends Thread{
       
 
    
    @Override
    public void run(){

        Random random = new Random();
        int numero = random.nextInt(6) + 1;
        
        switch(numero){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("one.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 l1.setIcon(scaledIcon1);
                 num1=1;
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("two.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l1.setIcon(scaledIcon2);
                num1=2;
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("three.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l1.setIcon(scaledIcon3);
                num1=3;
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("four.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l1.setIcon(scaledIcon4);
                num1=4;
            break;
            
             case 5:
                ImageIcon icon5 = new ImageIcon(getClass().getResource("five.png"));
                Image image5 = icon5.getImage();
                ImageIcon scaledIcon5 = new ImageIcon(image5.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l1.setIcon(scaledIcon5);
                num1=5;
            break;
            
             case 6:
                ImageIcon icon6 = new ImageIcon(getClass().getResource("six.png"));
                Image image6 = icon6.getImage();
                ImageIcon scaledIcon6 = new ImageIcon(image6.getScaledInstance(l1.getWidth(), l1.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l1.setIcon(scaledIcon6);
                num1=6;
            break;
              
        }
          
        
    }
   }
   
   public class proceso2 extends Thread{
        
   
    
    @Override
    public void run(){
        
        
        Random random = new Random();
        int numeros = random.nextInt(6) + 1;
        
        switch(numeros){
            
            case 1:
                 ImageIcon icon1 = new ImageIcon(getClass().getResource("one.png"));
                 Image image1 = icon1.getImage();
                 ImageIcon scaledIcon1 = new ImageIcon(image1.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                 l2.setIcon(scaledIcon1);
                 num2=1;
            break;
            
             case 2:
                ImageIcon icon2 = new ImageIcon(getClass().getResource("two.png"));
                Image image2 = icon2.getImage();
                ImageIcon scaledIcon2 = new ImageIcon(image2.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l2.setIcon(scaledIcon2);
                num2=2;
            break;
            
             case 3:
                ImageIcon icon3 = new ImageIcon(getClass().getResource("three.png"));
                Image image3 = icon3.getImage();
                ImageIcon scaledIcon3 = new ImageIcon(image3.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l2.setIcon(scaledIcon3);
                num2=3;
            break;
            
             case 4:
                ImageIcon icon4 = new ImageIcon(getClass().getResource("four.png"));
                Image image4 = icon4.getImage();
                ImageIcon scaledIcon4 = new ImageIcon(image4.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l2.setIcon(scaledIcon4);
                num2=4;
            break;
            
             case 5:
                ImageIcon icon5 = new ImageIcon(getClass().getResource("five.png"));
                Image image5 = icon5.getImage();
                ImageIcon scaledIcon5 = new ImageIcon(image5.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l2.setIcon(scaledIcon5);
                num2=5;
            break;
            
             case 6:
                ImageIcon icon6 = new ImageIcon(getClass().getResource("six.png"));
                Image image6 = icon6.getImage();
                ImageIcon scaledIcon6 = new ImageIcon(image6.getScaledInstance(l2.getWidth(), l2.getHeight(), java.awt.Image.SCALE_SMOOTH));
                l2.setIcon(scaledIcon6);
                num2=6;
            break;
              
        }
      
    }
   
}
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        jLabel2 = new javax.swing.JLabel();
        l1 = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        panel1.setBackground(new java.awt.Color(102, 102, 255));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("LANZAMIENTO DE DADOS");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2))
                .addContainerGap(126, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );

        jButton1.setBackground(new java.awt.Color(255, 255, 0));
        jButton1.setText("LANZAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        proceso1 hilo1 = new proceso1();
        proceso2 hilo2 = new proceso2();

        hilo1.start();
        hilo2.start();
        
           

    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Dados dialog = new Dados(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l2;
    private java.awt.Panel panel1;
    // End of variables declaration//GEN-END:variables
}
